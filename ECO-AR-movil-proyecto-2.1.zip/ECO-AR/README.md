# ECO-AR · Naturaleza en tus manos

Versión **2.1.0**, diseñada para usar desde Chrome de Android mediante un enlace de **GitHub Pages**, sin instalar una aplicación. El repositorio elegido es `andresebs/EcoAr`.

## Experiencia móvil

- Pantalla de cámara/visor que aprovecha el alto disponible, con controles accesibles sin desplazarse.
- Pato, ganso, pavo real y cinco etapas de lechuga, con selección durante el escaneo.
- Reconocimiento del logo completo de la Universidad de San Buenaventura mediante MindAR.
- Arrastrar para girar, pellizcar para ampliar, botones de giro, zoom, restablecimiento y rotación automática tanto en visor como en AR.
- Pantalla completa, información de especie y ayuda con el logo de referencia.
- Visor sin cámara, mensajes de error y cancelación del permiso pendiente. La cámara se detiene al volver al visor o salir de la pestaña.
- Compatibilidad con movimiento reducido, navegación por teclado, foco visible y avisos accesibles.

El visitante solo abre la URL publicada y acepta la cámara. **El enlace del repositorio muestra el código; el enlace de GitHub Pages ejecuta la aplicación.** La URL prevista es `https://andresebs.github.io/EcoAr/`, pendiente de publicación.

## Publicación

Consultar **PUBLICAR-GITHUB.md**. Hay dos opciones:

1. Subir el contenido de `pages-export/` y publicar con Pages desde `main` y `/(root)`. No requiere ejecutar herramientas de desarrollo en GitHub.
2. Subir este proyecto fuente completo, elegir GitHub Actions como origen y ejecutar manualmente el workflow incluido.

En esta sesión, la cuenta conectada es `asmc99`, con lectura pero **sin escritura** en `andresebs/EcoAr`. No se han subido cambios. Debe conectarse la cuenta autorizada o subir los archivos desde la cuenta propietaria.

## Desarrollar y probar

Node.js 22 o posterior y npm:

```sh
npm ci
npm run dev
```

Para verificar la entrega:

```sh
npm test
npm run build
npm run preview
```

Con Google Chrome instalado, ejecutar en otra terminal:

```sh
npm run test:browser
```

La prueba espera por defecto `http://127.0.0.1:4175/EcoAr/`. Para reproducir exactamente el entorno probado, iniciar el visor así:

```sh
npm run preview -- --base=/EcoAr/ --port=4175
```

También se puede definir `ECO_BASE_URL` con otra URL. El script guarda capturas y resultados en `test-results/`. Usa vídeo sintético, sin acceder a la cámara física.

Para crear la carpeta que se sube directamente a GitHub:

```sh
npm run export:pages
```

`dist/` es la compilación completa. `pages-export/` contiene solo los recursos que necesita la experiencia pública. No abrir HTML por doble clic: usar HTTPS o localhost. En el teléfono, usar la URL HTTPS de Pages; una dirección HTTP de la red local no habilita la cámara.

## Logo y modelos

Se debe escanear la **imagen completa de referencia**, incluido el texto de la universidad. La ayuda **Ver logo** muestra exactamente cuál es. No reconoce automáticamente cualquier variante, recorte o dibujo de la marca. Mantener buena luz, enfocar y evitar reflejos.

`public/assets/escudo.mind` se compiló desde la imagen original recuperada. `public/compilar.html` permite regenerarlo: guardar el resultado en el mismo lugar y volver a compilar. `public/models/` contiene ocho GLB reutilizables; la experiencia genera su geometría localmente para no descargarlos al cambiar de especie.

Los modelos son educativos y estilizados, no reconstrucciones anatómicas realistas. Las etapas de lechuga son orientativas y no representan días exactos de cultivo.

El ZIP de la conversación inicial no estaba disponible. Esta versión se reconstruyó a partir de las imágenes originales y se mejoró sobre la versión 2.0 preparada en esta sesión.

## Privacidad, bibliotecas y mantenimiento

La cámara se procesa en el dispositivo. No se envían imágenes a un backend y no hay analítica propia. Las bibliotecas de ejecución y las fuentes están disponibles localmente, sin CDN. GitHub Pages puede registrar accesos conforme a su propia política.

Three.js 0.151.3 y MindAR 1.2.5 (MIT), con licencias en `public/assets/`. MindAR incluye avisos de sus dependencias, entre ellas TensorFlow.js. Three.js se mantiene fijado por compatibilidad con MindAR.

Cambios locales de MindAR que se deben conservar al actualizar:

- Propagar errores de cámara e inicialización, y comprobar respuestas HTTP del marcador.
- Guardar la referencia del listener de resize para retirarlo al cerrar AR.
- Cancelar y detener el stream si el usuario cierra la cámara antes de resolver el permiso.
- Usar el nivel de seguimiento 0, más detallado, para el escudo: 19 puntos frente a 8 del nivel predeterminado, manteniendo el umbral original de similitud.

El código limita la densidad de píxeles, carga MindAR al solicitar cámara y libera geometrías al cambiar de modelo. Los recursos institucionales pertenecen a sus titulares. No se concede una licencia adicional sobre la marca universitaria.

## Alcance de la verificación

Consultar `PRUEBAS.md`. Se verificaron controles, tamaños, gestos, errores y reconocimiento con vídeo sintético. Queda pendiente la comprobación en Android físico con logo impreso, iluminación real y funcionamiento prolongado. No se ha realizado auditoría completa WCAG ni medición de FPS en teléfonos físicos.
