const { chromium } = require("playwright");
const fs = require("node:fs");
const assert = require("node:assert/strict");
const base = process.env.ECO_BASE_URL || "http://127.0.0.1:4175/EcoAr/";
(async () => {
  const browser = await chromium.launch({
    channel: process.env.ECO_BROWSER_CHANNEL || "chrome",
    headless: true,
  });
  const result = { base };
  const errors = [];
  fs.mkdirSync("test-results", { recursive: true });
  try {
    const page = await browser.newPage({
      viewport: { width: 390, height: 844 },
      hasTouch: true,
      isMobile: true,
    });
    page.on("pageerror", (e) => errors.push(e.message));
    await page.goto(base);
    await page.waitForFunction(() =>
      document.querySelector("#status").textContent.includes("Arrastra"),
    );
    const frame = () =>
      page.evaluate(
        () =>
          new Promise((r) =>
            requestAnimationFrame(() => requestAnimationFrame(r)),
          ),
      );
    const canvas = () => page.locator("#viewer canvas:visible").screenshot();
    for (const size of [
      { width: 390, height: 844 },
      { width: 360, height: 640 },
      { width: 320, height: 568 },
      { width: 844, height: 390 },
      { width: 1440, height: 1050 },
    ]) {
      await page.setViewportSize(size);
      await frame();
      assert.equal(
        await page.evaluate(
          () => document.documentElement.scrollWidth > innerWidth,
        ),
        false,
      );
      for (const id of [
        "ar",
        "marker",
        "help",
        "info",
        "left",
        "right",
        "zoom-in",
        "zoom-out",
        "reset",
        "rotate",
        "fullscreen",
      ]) {
        if (id === "help" && size.width > size.height && size.height < 550)
          continue;
        const b = await page.locator("#" + id).boundingBox();
        assert(
          b &&
            b.y >= 0 &&
            b.x >= 0 &&
            b.y + b.height <= size.height + 1 &&
            b.x + b.width <= size.width + 1,
          `${id} fuera de pantalla en ${size.width}x${size.height}`,
        );
        assert(
          await page.locator("#" + id).evaluate((el) => {
            const r = el.getBoundingClientRect();
            const top = document.elementFromPoint(
              r.x + r.width / 2,
              r.y + r.height / 2,
            );
            return top === el || el.contains(top);
          }),
          `${id} está tapado en ${size.width}x${size.height}`,
        );
      }
      await page.screenshot({
        path: `test-results/pantalla-${size.width}x${size.height}.png`,
      });
    }
    result.layouts = 5;
    await page.setViewportSize({ width: 390, height: 844 });
    for (const id of ["pato", "ganso", "pavo", "lechuga"]) {
      await page.locator(`[data-model="${id}"]`).click();
      assert.equal(
        await page.locator(`[data-model="${id}"]`).getAttribute("aria-pressed"),
        "true",
      );
      if (id === "lechuga")
        for (let i = 0; i < 5; i++)
          await page.selectOption("#stage", String(i));
    }
    result.modelSelection = true;
    result.lettuceStages = 5;
    await page.click("#info");
    assert(await page.locator("#info-dialog").evaluate((d) => d.open));
    await page.locator("#info-dialog .close").click();
    for (const id of ["help", "marker"]) {
      await page.click("#" + id);
      assert(await page.locator("#help-dialog").evaluate((d) => d.open));
      await page.locator("#help-dialog .close").click();
    }
    result.dialogButtons = true;
    await page.locator('[data-model="pavo"]').click();
    for (const id of ["right", "left", "zoom-in", "zoom-out"]) {
      const before = await canvas();
      await page.click("#" + id);
      await frame();
      assert(!before.equals(await canvas()), `${id} no cambió el visor`);
    }
    await page.click("#rotate");
    assert.equal(
      await page.locator("#rotate").getAttribute("aria-pressed"),
      "true",
    );
    await page.click("#reset");
    assert.equal(
      await page.locator("#rotate").getAttribute("aria-pressed"),
      "false",
    );
    result.viewerControls = true;
    await page.click("#fullscreen");
    await frame();
    assert.equal(
      await page.locator("#fullscreen").getAttribute("aria-pressed"),
      "true",
    );
    await page.click("#fullscreen");
    await frame();
    result.fullscreen = true;
    await page.evaluate(
      () =>
        (navigator.mediaDevices.getUserMedia = async () => {
          throw new DOMException("denied", "NotAllowedError");
        }),
    );
    await page.click("#ar");
    await page.waitForFunction(() =>
      document.querySelector("#status").textContent.includes("denegado"),
    );
    result.permissionDenied = true;
    await page.evaluate(async () => {
      const img = new Image();
      img.src = new URL("assets/escudo.png", document.baseURI);
      await img.decode();
      window.fakeCanvas = document.createElement("canvas");
      fakeCanvas.width = 640;
      fakeCanvas.height = 480;
      window.showTarget = true;
      window.fakeTimer = setInterval(() => {
        const ctx = fakeCanvas.getContext("2d");
        ctx.fillStyle = "white";
        ctx.fillRect(0, 0, 640, 480);
        if (window.showTarget) ctx.drawImage(img, 96, 16, 447, 447);
      }, 33);
      navigator.mediaDevices.getUserMedia = async () =>
        fakeCanvas.captureStream(30);
    });
    const waitFound = () =>
      page.waitForFunction(
        () =>
          document
            .querySelector("#status")
            .textContent.includes("Logo reconocido"),
        null,
        { timeout: 40000 },
      );
    await page.click("#ar");
    await waitFound();
    result.syntheticTargetFound = true;
    await page.screenshot({ path: "test-results/ar-movil.png" });
    for (const id of ["pato", "ganso", "pavo", "lechuga"]) {
      await page.locator(`[data-model="${id}"]`).click();
      if (id === "lechuga") {
        for (let i = 0; i < 5; i++)
          await page.selectOption("#stage", String(i));
      }
      assert(
        await page.evaluate(() => document.body.classList.contains("found")),
      );
    }
    result.modelsWhileTracking = true;
    await page.locator('[data-model="pavo"]').click();
    await frame();
    for (const id of ["right", "left", "zoom-in", "zoom-out"]) {
      const before = await canvas();
      await page.click("#" + id);
      await frame();
      assert(!before.equals(await canvas()), `${id} no cambió el modelo AR`);
    }
    await page.click("#rotate");
    assert.equal(
      await page.locator("#rotate").getAttribute("aria-pressed"),
      "true",
    );
    const before = await canvas();
    await frame();
    assert(!before.equals(await canvas()), "Rotación AR no visible");
    await page.click("#reset");
    result.arControls = true;
    const box = await page.locator("#viewer").boundingBox();
    const beforeDrag = await canvas();
    await page.mouse.move(box.x + box.width * 0.3, box.y + box.height * 0.6);
    await page.mouse.down();
    await page.mouse.move(box.x + box.width * 0.5, box.y + box.height * 0.6, {
      steps: 6,
    });
    await page.mouse.up();
    await frame();
    assert(!beforeDrag.equals(await canvas()));
    result.arDrag = true;
    const cdp = await page.context().newCDPSession(page);
    const beforePinch = await canvas();
    const cx = box.x + box.width * 0.4,
      cy = box.y + box.height * 0.55;
    const touches = (d) => [
      { x: cx - d, y: cy, id: 1 },
      { x: cx + d, y: cy, id: 2 },
    ];
    await cdp.send("Input.dispatchTouchEvent", {
      type: "touchStart",
      touchPoints: touches(20),
    });
    await cdp.send("Input.dispatchTouchEvent", {
      type: "touchMove",
      touchPoints: touches(45),
    });
    await cdp.send("Input.dispatchTouchEvent", {
      type: "touchEnd",
      touchPoints: [],
    });
    await frame();
    assert(
      !beforePinch.equals(await canvas()),
      "Pellizco AR no cambió el tamaño",
    );
    result.arPinch = true;
    await cdp.detach();
    await page.evaluate(() => (window.showTarget = false));
    await page.waitForFunction(() =>
      document.querySelector("#status").textContent.includes("fuera de vista"),
    );
    result.syntheticTargetLost = true;
    await page.click("#exit");
    assert.equal(await page.locator("#viewer video").count(), 0);
    result.cameraCleanup = true;
    await page.route("**/assets/escudo.mind", (r) =>
      r.fulfill({ status: 404, body: "not found" }),
    );
    await page.click("#ar");
    await page.waitForFunction(() =>
      document
        .querySelector("#status")
        .textContent.includes("No se pudo iniciar AR"),
    );
    result.missingMarkerError = true;
    await page.unroute("**/assets/escudo.mind");
    await page.evaluate(() => (window.showTarget = true));
    await page.click("#ar");
    await waitFound();
    await page.click("#exit");
    result.restartAfterError = true;
    await page.evaluate(() => {
      window.releaseCamera = null;
      navigator.mediaDevices.getUserMedia = () =>
        new Promise((r) => (window.releaseCamera = r));
    });
    await page.click("#ar");
    await page.waitForFunction(() => window.releaseCamera !== null);
    await page.click("#exit");
    await page.evaluate(() => {
      window.lateStream = fakeCanvas.captureStream(30);
      window.releaseCamera(lateStream);
    });
    await page.waitForFunction(() =>
      window.lateStream.getTracks().every((t) => t.readyState === "ended"),
    );
    assert.equal(await page.locator("#viewer video").count(), 0);
    result.cancelPendingCamera = true;
    await page.emulateMedia({ reducedMotion: "reduce" });
    await page.reload();
    await page.waitForFunction(() =>
      document.querySelector("#status").textContent.includes("Arrastra"),
    );
    await page.click("#rotate");
    assert.equal(
      await page.locator("#rotate").getAttribute("aria-pressed"),
      "false",
    );
    result.reducedMotion = true;
    assert.deepEqual(errors, []);
    result.unhandledErrors = errors;
    console.log(JSON.stringify(result, null, 2));
  } finally {
    fs.writeFileSync(
      "test-results/browser-results.json",
      JSON.stringify(result, null, 2),
    );
    await browser.close();
  }
})().catch((e) => {
  console.error(e);
  process.exit(1);
});
