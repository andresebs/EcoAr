import assert from "node:assert/strict";
import { readFile, stat } from "node:fs/promises";
import { catalog, createModel, disposeModel } from "../src/models.js";
let total = 0;
for (const d of catalog) {
  for (const stage of d.id === "lechuga" ? [0, 1, 2, 3, 4] : [0]) {
    const g = createModel(d.id, stage);
    let meshes = 0;
    g.traverse((o) => {
      if (o.isMesh) {
        meshes++;
        assert(o.geometry.attributes.position.count > 0);
        for (const v of o.geometry.attributes.position.array)
          assert(Number.isFinite(v));
      }
    });
    assert(meshes > 0);
    disposeModel(g);
    total++;
  }
}
for (const f of [
  "escudo.png",
  "infografia.png",
  "escudo.mind",
  "mindar-image-three.prod.js",
  "mindar-image.prod.js",
  "controller-mGt1s8dJ.js",
  "ui-fBadYuor.js",
])
  assert((await stat("public/assets/" + f)).size > 0);
const html = await readFile("index.html", "utf8");
assert(html.includes('lang="es"'));
assert(html.includes('aria-live="polite"'));
for (const name of [
  "pato",
  "ganso",
  "pavo",
  "lechuga-0",
  "lechuga-1",
  "lechuga-2",
  "lechuga-3",
  "lechuga-4",
]) {
  const b = await readFile("public/models/" + name + ".glb");
  assert.equal(b.toString("ascii", 0, 4), "glTF");
  assert.equal(b.readUInt32LE(4), 2);
  assert.equal(b.readUInt32LE(8), b.length);
}
console.log(
  `OK: ${total} modelos/etapas, geometría finita, recursos y accesibilidad básica.`,
);
