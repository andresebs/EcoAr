import { cp, mkdir, readdir, writeFile, readFile } from "node:fs/promises";
import { join } from "node:path";
const out = "pages-export";
await mkdir(out, { recursive: true });
async function copy(dir, rel = "") {
  for (const file of await readdir(dir, { withFileTypes: true })) {
    const path = join(rel, file.name);
    if (file.isDirectory()) {
      if (file.name === "models") continue;
      await copy(join(dir, file.name), path);
      continue;
    }
    if (
      ["compilar.html", "infografia.png", "mindar-image.prod.js"].includes(
        file.name,
      )
    )
      continue;
    const target = join(out, path);
    await mkdir(join(target, ".."), { recursive: true });
    await cp(join(dir, file.name), target);
  }
}
await copy("dist");
await writeFile(join(out, ".nojekyll"), "");
await writeFile(
  join(out, "README.md"),
  await readFile("PUBLICAR-GITHUB.md", "utf8"),
);
console.log(
  "pages-export/ lista: subir su contenido a la raíz de andresebs/EcoAr.",
);
