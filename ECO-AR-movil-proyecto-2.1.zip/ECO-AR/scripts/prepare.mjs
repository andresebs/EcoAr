import { copyFile, mkdir } from "node:fs/promises";
await mkdir("public/assets", { recursive: true });
await copyFile(
  "node_modules/three/build/three.module.js",
  "public/assets/three.module.js",
);
await copyFile("node_modules/three/LICENSE", "public/assets/THREE-LICENSE.txt");
await mkdir("public/assets/addons/renderers", { recursive: true });
await copyFile(
  "node_modules/three/examples/jsm/renderers/CSS3DRenderer.js",
  "public/assets/addons/renderers/CSS3DRenderer.js",
);
