# ECO-AR · Web móvil, sin instalación

Repositorio elegido: **andresebs/EcoAr**.

La aplicación se usa en Chrome de Android desde el enlace de GitHub Pages. El visitante no instala APK, no descarga un ZIP y no necesita una cuenta de GitHub. Debe permitir la cámara cuando toque **Escanear logo**.

## Publicar la carpeta ya preparada

1. Inicia sesión en GitHub con **andresebs**, o con una cuenta que tenga permisos de escritura en este repositorio.
2. En el repositorio, elige **Add file → Upload files** (o **uploading an existing file** si está vacío).
3. Arrastra el **contenido** de la carpeta `pages-export/`: `index.html`, `assets/`, `.nojekyll` y `README.md`. No subas el ZIP ni dejes `index.html` dentro de otra carpeta.
4. Confirma la subida con **Commit changes** en la rama `main`.
5. Ve a **Settings → Pages → Build and deployment**. Elige **Deploy from a branch**, rama **main**, carpeta **/(root)** y **Save**.
6. Espera a que GitHub indique que la publicación finalizó y abre el enlace mostrado.

La dirección prevista es **https://andresebs.github.io/EcoAr/**. Solo estará activa después de publicar; esta entrega no afirma que ya esté disponible.

## Usar la aplicación

Abre el enlace publicado en Chrome del celular, toca **Escanear logo** y permite la cámara. Apunta al logo completo de la Universidad de San Buenaventura que aparece en **Ver logo**, colocado en otra pantalla o impreso. No es un lector QR: reconoce esa imagen de referencia.

Cuando el logo se reconoce, aparece la especie seleccionada. Cambia entre pato, ganso, pavo real y lechuga sin cerrar la cámara. En lechuga, cambia la etapa. Arrastra para girar, pellizca para ampliar o utiliza los controles. **Volver al visor 3D** apaga la cámara.

## Actualizaciones desde el código fuente

El ZIP del proyecto completo incluye un workflow alternativo de GitHub Actions que compila `dist/`. Para usarlo, sube el proyecto fuente completo y selecciona **GitHub Actions** en Settings → Pages. Después ejecuta manualmente **Publicar ECO-AR en Pages** en Actions. No mezcles ambas formas de publicación sin cambiar el origen en Settings → Pages.

Documentación oficial: https://docs.github.com/en/pages/getting-started-with-github-pages/what-is-github-pages
