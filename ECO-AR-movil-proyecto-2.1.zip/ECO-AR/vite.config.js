import { defineConfig } from "vite";
import { readFileSync, existsSync } from "node:fs";
import { resolve } from "node:path";
export default defineConfig({
  plugins: [
    {
      name: "local-mindar-modules",
      configureServer(server) {
        server.middlewares.use((req, res, next) => {
          const path = (req.url || "").split("?")[0];
          if (/^\/assets\/[\w.-]+\.js$/.test(path)) {
            const file = resolve("public", path.slice(1));
            if (existsSync(file)) {
              res.setHeader("Content-Type", "text/javascript");
              res.end(readFileSync(file));
              return;
            }
          }
          next();
        });
      },
    },
  ],
  optimizeDeps: {
    noDiscovery: true,
    include: ["three", "three/addons/controls/OrbitControls.js"],
  },
});
