import * as T from "three";
export const catalog = [
  {
    id: "pato",
    icon: "🦆",
    name: "Pato",
    latin: "Anas platyrhynchos",
    description:
      "El ánade real habita humedales y lagunas. Sus patas palmeadas impulsan el cuerpo en el agua y su pico ancho ayuda a recoger alimento.",
    fact: "Observa el cuello corto, la cabeza verde del macho y el cuerpo adaptado a nadar.",
  },
  {
    id: "ganso",
    icon: "🪿",
    name: "Ganso",
    latin: "Anser anser · forma doméstica",
    description:
      "Ave social de cuello largo. Se alimenta principalmente de vegetación y se comunica mediante llamadas y posturas.",
    fact: "Compara su cuello y su postura con los del pato. El modelo representa un ganso doméstico blanco.",
  },
  {
    id: "pavo",
    icon: "🦚",
    name: "Pavo real",
    latin: "Pavo cristatus",
    description:
      "El macho despliega sus largas plumas de cobertura durante el cortejo. Los ocelos son los patrones que parecen ojos.",
    fact: "El abanico representa la ornamentación del macho; la hembra tiene un plumaje más discreto.",
  },
  {
    id: "lechuga",
    icon: "🌱",
    name: "Lechuga",
    latin: "Lactuca sativa",
    description:
      "De una semilla surge la raíz y después las primeras hojas. La planta desarrolla una roseta que aumenta de tamaño hasta la cosecha.",
    fact: "Cambia de etapa para observar una secuencia educativa. El ritmo depende de la variedad y las condiciones de cultivo.",
  },
];
const materials = new Map();
function mat(color) {
  if (!materials.has(color))
    materials.set(
      color,
      new T.MeshStandardMaterial({ color, roughness: 0.78 }),
    );
  return materials.get(color);
}
function ell(g, c, p, s) {
  const m = new T.Mesh(new T.SphereGeometry(1, 20, 12), mat(c));
  m.position.set(...p);
  m.scale.set(...s);
  g.add(m);
  return m;
}
function cone(g, c, p, r, h, rotation = 0) {
  const m = new T.Mesh(new T.ConeGeometry(r, h, 16), mat(c));
  m.position.set(...p);
  m.rotation.x = rotation;
  g.add(m);
  return m;
}
function stem(g, a, b, r = 0.025, c = "#72983e") {
  const av = new T.Vector3(...a),
    bv = new T.Vector3(...b),
    d = bv.clone().sub(av);
  const m = new T.Mesh(new T.CylinderGeometry(r, r, d.length(), 10), mat(c));
  m.position.copy(av.add(bv).multiplyScalar(0.5));
  m.quaternion.setFromUnitVectors(new T.Vector3(0, 1, 0), d.normalize());
  g.add(m);
}
function leaf(g, p, size, angle, color) {
  const geo = new T.BufferGeometry(),
    v = [],
    idx = [];
  const n = 12;
  for (let i = 0; i <= n; i++) {
    const t = i / n,
      w = Math.sin(t * Math.PI) * size * 0.36 * (1 + 0.1 * Math.sin(t * 25));
    for (const side of [-1, 1])
      v.push(
        side * w,
        size * t * 0.55 + Math.sin(t * Math.PI) * size * 0.1,
        size * t,
      );
  }
  for (let i = 0; i < n; i++) {
    let j = i * 2;
    idx.push(j, j + 1, j + 2, j + 1, j + 3, j + 2);
  }
  geo.setAttribute("position", new T.Float32BufferAttribute(v, 3));
  geo.setIndex(idx);
  geo.computeVertexNormals();
  const m = new T.Mesh(
    geo,
    new T.MeshStandardMaterial({ color, side: T.DoubleSide, roughness: 0.8 }),
  );
  m.position.set(...p);
  m.rotation.y = angle;
  g.add(m);
  const end = [
    p[0] + Math.sin(angle) * size,
    p[1] + size * 0.55,
    p[2] + Math.cos(angle) * size,
  ];
  stem(g, p, end, 0.009, "#a5c56a");
}
export function createModel(id, stage = 0) {
  const g = new T.Group();
  g.name = id;
  ell(g, "#805236", [0, 0.025, 0], [0.92, 0.09, 0.68]);
  if (id === "lechuga") {
    if (stage === 0) {
      ell(g, "#d6bf7e", [0, 0.16, 0], [0.06, 0.025, 0.13]);
      return g;
    }
    stem(g, [0, 0.08, 0], [0, 0.22 + stage * 0.06, 0], 0.025);
    const count = [0, 2, 5, 10, 18][stage];
    for (let i = 0; i < count; i++) {
      const ring = Math.floor(i / 6),
        size = (0.19 + stage * 0.13) * (1 - ring * 0.2);
      leaf(
        g,
        [0, 0.12 + ring * 0.09, 0],
        size,
        i * 2.399,
        i % 2 ? "#71a93c" : "#4d8f31",
      );
    }
    return g;
  }
  const goose = id === "ganso",
    peacock = id === "pavo";
  const body = peacock ? "#075782" : goose ? "#eeeadd" : "#76604a";
  ell(g, body, [0, 0.54, 0], [0.52, 0.35, 0.73]);
  const wing = ell(
    g,
    goose ? "#d6d5c8" : peacock ? "#158184" : "#9b8770",
    [0.38, 0.61, 0.02],
    [0.18, 0.25, 0.46],
  );
  wing.rotation.z = -0.2;
  ell(
    g,
    wing.material.color.getStyle(),
    [-0.38, 0.61, 0.02],
    [0.18, 0.25, 0.46],
  );
  for (const x of [-0.22, 0.22]) {
    stem(g, [x, 0.12, 0.1], [x, 0.4, 0.08], 0.035, "#ce7b19");
    ell(g, "#dd8b22", [x, 0.11, 0.24], [0.14, 0.035, 0.22]);
  }
  const hy = goose ? 1.5 : peacock ? 1.2 : 1.0;
  stem(
    g,
    [0, 0.65, 0.36],
    [0, hy - 0.12, 0.5],
    goose ? 0.13 : 0.15,
    goose ? "#f4f1e7" : peacock ? "#0955a0" : "#176c43",
  );
  ell(
    g,
    goose ? "#f4f1e7" : peacock ? "#1261ad" : "#13764d",
    [0, hy, 0.53],
    [0.23, 0.23, 0.26],
  );
  cone(g, "#e5a026", [0, hy - 0.03, 0.88], 0.13, 0.36, Math.PI / 2);
  for (const x of [-0.205, 0.205]) {
    ell(g, "#141d17", [x, hy + 0.06, 0.66], [0.032, 0.037, 0.035]);
    ell(g, "#ffffff", [x * 1.025, hy + 0.073, 0.67], [0.01, 0.012, 0.01]);
  }
  if (peacock) {
    for (let i = 0; i < 17; i++) {
      const a = (i / 16 - 0.5) * Math.PI * 1.15;
      const x = Math.sin(a) * 1.24,
        y = 0.7 + Math.cos(a) * 1.48;
      stem(g, [0, 0.45, -0.42], [x, y, -0.62], 0.035, "#437e53");
      const f = ell(
        g,
        i % 2 ? "#359066" : "#557f37",
        [x, y, -0.65],
        [0.14, 0.35, 0.045],
      );
      f.rotation.z = -a;
      ell(g, "#d1ac31", [x, y + 0.04, -0.59], [0.095, 0.13, 0.025]);
      ell(g, "#125772", [x, y + 0.04, -0.56], [0.06, 0.085, 0.02]);
      ell(g, "#102b58", [x, y + 0.04, -0.54], [0.027, 0.047, 0.015]);
    }
    for (let i = -1; i <= 1; i++) {
      stem(
        g,
        [0, hy + 0.17, 0.53],
        [i * 0.08, hy + 0.4, 0.54],
        0.012,
        "#075782",
      );
      ell(g, "#21a1a5", [i * 0.08, hy + 0.4, 0.54], [0.04, 0.045, 0.03]);
    }
  } else {
    const tail = cone(g, body, [0, 0.7, -0.72], 0.22, 0.48, -Math.PI / 2);
    tail.rotation.x = -Math.PI / 3;
    if (!goose) ell(g, "#e3ddd0", [0, 0.85, 0.48], [0.16, 0.035, 0.16]);
  }
  return g;
}
export function disposeModel(g) {
  g.traverse((o) => {
    if (o.geometry) o.geometry.dispose();
    if (o.material && !Array.from(materials.values()).includes(o.material))
      o.material.dispose();
  });
}
