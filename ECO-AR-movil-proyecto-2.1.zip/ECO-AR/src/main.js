import "./style.css";
import * as T from "three";
import { OrbitControls } from "three/addons/controls/OrbitControls.js";
import { catalog, createModel, disposeModel } from "./models.js";
const $ = (id) => document.getElementById(id),
  host = $("viewer");
let selected = "pato",
  stage = 0,
  renderer,
  scene,
  camera,
  controls,
  model,
  ar = null,
  arModel = null;
let busy = false,
  auto = false,
  scale = 1,
  session = 0,
  wakeLock = null,
  found = false,
  ready = false;
const reduced = matchMedia("(prefers-reduced-motion: reduce)").matches;
const pointers = new Map();
function status(text) {
  $("status").textContent = text;
}
function fitViewer() {
  if (!model || !controls) return;
  const bounds = new T.Box3().setFromObject(model),
    size = bounds.getSize(new T.Vector3()),
    center = bounds.getCenter(new T.Vector3());
  const aspect = Math.max(
    0.4,
    host.clientWidth / Math.max(1, host.clientHeight),
  );
  const distance =
    (Math.max(size.y, size.x / aspect, size.z) * 1.35) /
    (2 * Math.tan(T.MathUtils.degToRad(camera.fov / 2)));
  controls.target.copy(center);
  camera.position
    .copy(center)
    .add(
      new T.Vector3(0.55, 0.28, 1)
        .normalize()
        .multiplyScalar(Math.max(1.4, distance)),
    );
  controls.minDistance = Math.max(0.6, distance * 0.45);
  controls.maxDistance = Math.max(6, distance * 2.5);
  controls.update();
}
function update() {
  const d = catalog.find((d) => d.id === selected);
  for (const key of ["name", "latin", "description", "fact"])
    $(key).textContent = d[key];
  $("selected-name").textContent = d.name;
  $("stages").hidden = selected !== "lechuga";
  document
    .querySelectorAll("[data-model]")
    .forEach((b) =>
      b.setAttribute("aria-pressed", String(b.dataset.model === selected)),
    );
  host.setAttribute(
    "aria-label",
    `Modelo 3D: ${d.name}. Arrastra para girar o usa los controles.`,
  );
  if (!scene) return;
  if (model) {
    scene.remove(model);
    disposeModel(model);
  }
  model = createModel(selected, stage);
  scene.add(model);
  fitViewer();
  if (ar) {
    if (arModel) {
      ar.anchor.group.remove(arModel);
      disposeModel(arModel);
    }
    arModel = createModel(selected, stage);
    arModel.scale.setScalar(0.19 * scale);
    arModel.rotation.set(0.1, -0.4, 0);
    arModel.position.set(-0.08, -0.3, 0.05);
    ar.anchor.group.add(arModel);
  }
}
for (const d of catalog) {
  const b = document.createElement("button");
  b.dataset.model = d.id;
  b.innerHTML = `<span aria-hidden="true">${d.icon}</span>${d.name}`;
  b.onclick = () => {
    selected = d.id;
    scale = 1;
    update();
  };
  $("choices").append(b);
}
function resize() {
  if (!renderer) return;
  const w = host.clientWidth,
    h = host.clientHeight;
  if (!w || !h) return;
  renderer.setSize(w, h);
  camera.aspect = w / h;
  camera.updateProjectionMatrix();
  if (ar?.controller && ar.video?.videoWidth) ar.resize();
}
function reset() {
  scale = 1;
  auto = false;
  $("rotate").setAttribute("aria-pressed", "false");
  if (arModel) {
    arModel.rotation.set(0.1, -0.4, 0);
    arModel.scale.setScalar(0.19);
  }
  if (model) model.rotation.set(0, 0, 0);
  fitViewer();
}
function spin(time, state) {
  const elapsed = Math.min(100, Math.max(0, time - (state.last || time)));
  state.last = time;
  if (auto && !reduced) (arModel || model).rotation.y += elapsed * 0.0005;
}
try {
  scene = new T.Scene();
  camera = new T.PerspectiveCamera(42, 1, 0.03, 60);
  renderer = new T.WebGLRenderer({ antialias: true, alpha: true });
  renderer.setPixelRatio(Math.min(devicePixelRatio, 1.5));
  renderer.outputEncoding = T.sRGBEncoding;
  host.append(renderer.domElement);
  scene.add(new T.HemisphereLight(0xffffff, 0x637347, 0.85));
  const light = new T.DirectionalLight(0xffffff, 0.8);
  light.position.set(3, 5, 4);
  scene.add(light);
  controls = new OrbitControls(camera, renderer.domElement);
  controls.enablePan = false;
  controls.maxPolarAngle = Math.PI * 0.49;
  update();
  new ResizeObserver(resize).observe(host);
  resize();
  const clock = {};
  renderer.setAnimationLoop((time) => {
    if (!ar && !document.hidden) {
      spin(time, clock);
      controls.update();
      renderer.render(scene, camera);
    }
  });
  ready = true;
  status("Arrastra para girar · Toca Escanear logo para usar la cámara.");
} catch (e) {
  status(
    "No se pudo iniciar 3D. Reabre el enlace en Chrome con WebGL habilitado.",
  );
  console.error(e);
  $("ar").disabled = true;
  document
    .querySelectorAll(".tools button")
    .forEach((b) => (b.disabled = true));
}
$("stage").onchange = (e) => {
  stage = Number(e.target.value);
  update();
};
for (const [id, delta] of [
  ["left", -0.25],
  ["right", 0.25],
])
  $(id).onclick = () => {
    if (ready) (arModel || model).rotation.y += delta;
  };
function zoom(factor) {
  if (!ready) return;
  if (arModel) {
    scale = T.MathUtils.clamp(scale * factor, 0.4, 2.2);
    arModel.scale.setScalar(0.19 * scale);
  } else {
    const delta = camera.position.clone().sub(controls.target);
    delta.setLength(
      T.MathUtils.clamp(
        delta.length() / factor,
        controls.minDistance,
        controls.maxDistance,
      ),
    );
    camera.position.copy(controls.target).add(delta);
    controls.update();
  }
}
$("zoom-in").onclick = () => zoom(1.15);
$("zoom-out").onclick = () => zoom(1 / 1.15);
$("reset").onclick = reset;
$("rotate").onclick = () => {
  if (reduced) {
    status(
      "La rotación automática está desactivada por tu preferencia de movimiento reducido.",
    );
    return;
  }
  auto = !auto;
  $("rotate").setAttribute("aria-pressed", String(auto));
};
function showDialog(id) {
  $(id).showModal();
}
$("info").onclick = () => showDialog("info-dialog");
$("help").onclick = $("marker").onclick = () => showDialog("help-dialog");
for (const dialog of document.querySelectorAll("dialog")) {
  dialog.querySelector(".close").onclick = () => dialog.close();
  dialog.addEventListener("click", (e) => {
    if (e.target === dialog) {
      const r = dialog.getBoundingClientRect();
      if (
        e.clientX < r.left ||
        e.clientX > r.right ||
        e.clientY < r.top ||
        e.clientY > r.bottom
      )
        dialog.close();
    }
  });
}
function syncFullscreen() {
  const full =
    !!document.fullscreenElement || document.body.classList.contains("focus");
  $("fullscreen").setAttribute("aria-pressed", String(full));
  $("fullscreen").setAttribute(
    "aria-label",
    full ? "Salir de pantalla completa" : "Ampliar a pantalla completa",
  );
  resize();
}
$("fullscreen").onclick = async () => {
  try {
    if (document.fullscreenElement) await document.exitFullscreen();
    else if (document.body.classList.contains("focus"))
      document.body.classList.remove("focus");
    else if (document.documentElement.requestFullscreen)
      await document.documentElement.requestFullscreen();
    else document.body.classList.add("focus");
  } catch {
    document.body.classList.toggle("focus");
  }
  syncFullscreen();
};
document.addEventListener("fullscreenchange", syncFullscreen);
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape" && document.body.classList.contains("focus")) {
    document.body.classList.remove("focus");
    syncFullscreen();
  }
});
function disposeAR(current) {
  if (!current) return;
  current._ecoCanceled = true;
  current.renderer.setAnimationLoop(null);
  current.controller?.stopProcessVideo();
  current.video?.srcObject?.getTracks().forEach((t) => t.stop());
  current.video?.remove();
  window.removeEventListener("resize", current._ecoResizeHandler);
  current.cssRenderer?.domElement.remove();
  current.controller?.dispose();
  current.controller?.worker?.terminate();
  current.renderer.dispose();
  current.renderer.domElement.remove();
  current.scene.clear();
}
function stopAR(
  message = "Cámara detenida. Puedes seguir explorando en el visor.",
) {
  session++;
  busy = false;
  const current = ar;
  ar = null;
  found = false;
  pointers.clear();
  disposeAR(current);
  if (arModel) disposeModel(arModel);
  arModel = null;
  wakeLock?.release().catch(() => {});
  wakeLock = null;
  host.querySelectorAll("video").forEach((v) => {
    v.srcObject?.getTracks().forEach((t) => t.stop());
    v.remove();
  });
  if (renderer) renderer.domElement.hidden = false;
  document.body.classList.remove("ar", "found");
  $("ar").hidden = false;
  $("ar").disabled = !ready;
  $("exit").hidden = true;
  $("exit").textContent = "Volver al visor 3D";
  $("mode-label").textContent = "VISOR 3D · SIN CÁMARA";
  resize();
  status(message);
}
$("exit").onclick = () => stopAR();
$("ar").onclick = async () => {
  if (busy || ar || !ready) return;
  if (!isSecureContext || !navigator.mediaDevices?.getUserMedia) {
    status(
      "Abre el enlace HTTPS de GitHub Pages en Chrome y habilita la cámara.",
    );
    return;
  }
  const token = ++session;
  busy = true;
  $("ar").hidden = true;
  $("exit").hidden = false;
  $("exit").textContent = "Cancelar cámara";
  status("Preparando cámara… Permite su uso cuando Chrome lo solicite.");
  let mind;
  try {
    const { MindARThree } = await import(
      /* @vite-ignore */ new URL(
        "assets/mindar-image-three.prod.js",
        document.baseURI,
      ).href
    );
    if (token !== session) return;
    mind = new MindARThree({
      container: host,
      imageTargetSrc: new URL("assets/escudo.mind", document.baseURI).href,
      uiLoading: "no",
      uiScanning: "no",
      uiError: "no",
      filterMinCF: 0.001,
      filterBeta: 1000,
    });
    ar = mind;
    mind.anchor = mind.addAnchor(0);
    mind.anchor.onTargetFound = () => {
      if (ar !== mind) return;
      found = true;
      document.body.classList.add("found");
      status("Logo reconocido · Modelo sobre la imagen.");
      $("mode-label").textContent = "CÁMARA AR · LOGO RECONOCIDO";
    };
    mind.anchor.onTargetLost = () => {
      if (ar !== mind) return;
      found = false;
      document.body.classList.remove("found");
      status("Logo fuera de vista. Vuelve a encuadrar la imagen completa.");
      $("mode-label").textContent = "CÁMARA AR · BUSCANDO LOGO";
    };
    mind.scene.add(new T.HemisphereLight(0xffffff, 0x647451, 0.95));
    update();
    renderer.domElement.hidden = true;
    document.body.classList.add("ar");
    await mind.start();
    if (token !== session || ar !== mind) {
      disposeAR(mind);
      return;
    }
    mind.video.style.zIndex = "0";
    mind.video.muted = true;
    mind.cssRenderer.domElement.style.pointerEvents = "none";
    mind.renderer.setPixelRatio(Math.min(devicePixelRatio, 1.5));
    resize();
    const clock = {};
    mind.renderer.setAnimationLoop((time) => {
      if (!document.hidden) {
        spin(time, clock);
        mind.renderer.render(mind.scene, mind.camera);
      }
    });
    $("exit").textContent = "Volver al visor 3D";
    if (!found) {
      $("mode-label").textContent = "CÁMARA AR · BUSCANDO LOGO";
      status(
        "Apunta al logo completo de la universidad. Mantén el celular estable.",
      );
    }
    if (navigator.wakeLock)
      try {
        const lock = await navigator.wakeLock.request("screen");
        if (ar === mind) wakeLock = lock;
        else await lock.release();
      } catch {}
  } catch (e) {
    if (token !== session) return;
    console.warn("Cámara AR:", e);
    const denied = e?.name === "NotAllowedError",
      missing = e?.name === "NotFoundError",
      used = e?.name === "NotReadableError";
    stopAR(
      denied
        ? "Permiso de cámara denegado. Habilítalo en Chrome o utiliza el visor."
        : missing
          ? "No se encontró una cámara. Puedes explorar en el visor 3D."
          : used
            ? "La cámara está ocupada. Cierra otras aplicaciones que la usen y reintenta."
            : "No se pudo iniciar AR. Revisa la conexión y vuelve a tocar Escanear logo.",
    );
  } finally {
    if (token === session) {
      busy = false;
      $("ar").disabled = !ready;
    }
  }
};
// Los gestos del visor los gestiona OrbitControls; en AR transforman el modelo anclado.
let pinchDistance = 0;
const distance = () => {
  const p = [...pointers.values()];
  return p.length < 2 ? 0 : Math.hypot(p[0].x - p[1].x, p[0].y - p[1].y);
};
host.addEventListener("pointerdown", (e) => {
  if (!arModel || busy) return;
  pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
  host.setPointerCapture(e.pointerId);
  pinchDistance = distance();
});
host.addEventListener("pointermove", (e) => {
  if (!arModel || !pointers.has(e.pointerId)) return;
  const previous = pointers.get(e.pointerId);
  pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
  if (pointers.size === 1) {
    arModel.rotation.y += (e.clientX - previous.x) * 0.012;
    arModel.rotation.x = T.MathUtils.clamp(
      arModel.rotation.x + (e.clientY - previous.y) * 0.006,
      -0.5,
      0.7,
    );
  } else {
    const next = distance();
    if (pinchDistance > 0) zoom(next / pinchDistance);
    pinchDistance = next;
  }
});
for (const event of ["pointerup", "pointercancel", "lostpointercapture"])
  host.addEventListener(event, (e) => {
    pointers.delete(e.pointerId);
    pinchDistance = distance();
  });
document.addEventListener("visibilitychange", () => {
  if (document.hidden && (ar || busy))
    stopAR("Cámara pausada al salir. Toca Escanear logo para volver.");
});
window.addEventListener("pagehide", () => {
  if (ar || busy) stopAR();
});
