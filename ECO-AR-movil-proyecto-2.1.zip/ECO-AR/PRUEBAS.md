# Verificación ECO-AR móvil · 2.1.0

Fecha: 20 de octubre de 2026. Destino: `andresebs/EcoAr`, GitHub Pages. Verificación local en una ruta `/EcoAr/` equivalente a la publicación prevista.

## Resultados

- Build de producción correcto y ocho modelos/etapas con geometría finita.
- Ocho GLB con cabeceras y longitudes válidas.
- Cinco pantallas: 390×844, 360×640, 320×568, 844×390 y 1440×1050.
- Botones dentro de la pantalla y sin otros elementos que tapen su centro; sin desbordamiento horizontal.
- Selección de las cuatro especies y de las cinco etapas de lechuga.
- Ayuda, visualización del logo, información y pantalla completa.
- Giro y zoom comprobados mediante comparación de la imagen renderizada.
- Rotación automática y restablecimiento en visor y AR.
- Reconocimiento del logo y pérdida de imagen con vídeo sintético de referencia.
- Cambio de modelo y etapas durante seguimiento activo.
- Arrastre y pellizco de dos dedos para transformar el modelo AR.
- Permiso denegado, marcador con respuesta 404, recuperación después del error.
- Cancelación con un permiso de cámara pendiente: el stream que llega tarde se detiene.
- Cámara retirada al volver al visor y preferencia de movimiento reducido respetada.
- Ningún error JavaScript sin controlar en la prueba final.

## Límites

Las pruebas de navegador se ejecutan en Chrome automatizado, con emulación móvil y vídeo sintético. No constituyen una prueba en un Android físico. Antes de presentar la experiencia, comprobar cámara real, logo impreso, luz, reflejos, orientación y rendimiento sostenido. No se ha auditado completamente WCAG ni probado con lector de pantalla.

El marcador es el logo completo mostrado en la ayuda, incluido el nombre de la universidad. La prueba no demuestra reconocimiento de otras versiones o recortes del logo.

No se ha publicado: el repositorio está vacío y la conexión actual no dispone de escritura. La URL prevista de Pages aún necesita subir los archivos y activar la publicación.

## Reproducir

`npm ci`, `npm test`, `npm run build`, `npm run preview -- --base=/EcoAr/ --port=4175`. En otra terminal, con Chrome instalado, `npm run test:browser`.

Los resultados y las capturas se guardan en `test-results/`. El test emula la entrada de cámara y no usa el dispositivo físico.
